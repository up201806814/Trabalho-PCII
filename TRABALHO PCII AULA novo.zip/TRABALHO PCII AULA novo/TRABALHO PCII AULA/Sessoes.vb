﻿Public Class Sessoes
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewSessao As Sessao)
        Me.List.Add(NewSessao)
    End Sub

    Public Sub Remove(ByVal oldSessao As Sessao)
        Me.List.Remove(oldSessao)
    End Sub

    Default Public Property item(ByVal index As Integer) As Sessao
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As Sessao)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewSessao As Sessao)
        Me.List.Insert(index, NewSessao)
    End Sub
End Class

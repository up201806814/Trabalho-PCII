﻿Public Class Vendas

    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewVenda As Venda)
        Me.List.Add(NewVenda)
    End Sub

    Public Sub Remove(ByVal oldVenda As Venda)
        Me.List.Remove(oldVenda)
    End Sub

    Default Public Property item(ByVal index As Integer) As Venda
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As Venda)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewVenda As Venda)
        Me.List.Insert(index, NewVenda)
    End Sub


End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Alterar_Password
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.alterar = New System.Windows.Forms.Button()
        Me.passrepetida = New System.Windows.Forms.TextBox()
        Me.passnova = New System.Windows.Forms.TextBox()
        Me.passantiga = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'alterar
        '
        Me.alterar.Location = New System.Drawing.Point(217, 154)
        Me.alterar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.alterar.Name = "alterar"
        Me.alterar.Size = New System.Drawing.Size(125, 30)
        Me.alterar.TabIndex = 13
        Me.alterar.Text = "Alterar Password"
        Me.alterar.UseVisualStyleBackColor = True
        '
        'passrepetida
        '
        Me.passrepetida.Location = New System.Drawing.Point(217, 111)
        Me.passrepetida.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.passrepetida.Name = "passrepetida"
        Me.passrepetida.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.passrepetida.Size = New System.Drawing.Size(124, 22)
        Me.passrepetida.TabIndex = 12
        '
        'passnova
        '
        Me.passnova.Location = New System.Drawing.Point(217, 81)
        Me.passnova.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.passnova.Name = "passnova"
        Me.passnova.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.passnova.Size = New System.Drawing.Size(124, 22)
        Me.passnova.TabIndex = 11
        '
        'passantiga
        '
        Me.passantiga.Location = New System.Drawing.Point(217, 52)
        Me.passantiga.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.passantiga.Name = "passantiga"
        Me.passantiga.Size = New System.Drawing.Size(124, 22)
        Me.passantiga.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(69, 116)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(130, 17)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Repita a Password:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(110, 17)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Nova Password:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 17)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Password Atual:"
        '
        'Alterar_Password
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.alterar)
        Me.Controls.Add(Me.passrepetida)
        Me.Controls.Add(Me.passnova)
        Me.Controls.Add(Me.passantiga)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Alterar_Password"
        Me.Text = "0000000000"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents alterar As Button
    Friend WithEvents passrepetida As TextBox
    Friend WithEvents passnova As TextBox
    Friend WithEvents passantiga As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class

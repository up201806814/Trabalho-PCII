﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormFilmes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TextBoxnome = New System.Windows.Forms.TextBox()
        Me.TextBoxgenero = New System.Windows.Forms.TextBox()
        Me.TextBoxsessoes = New System.Windows.Forms.TextBox()
        Me.TextBoxsala = New System.Windows.Forms.TextBox()
        Me.TextBoxidade = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.SuspendLayout()
        '
        'TextBoxnome
        '
        Me.TextBoxnome.Location = New System.Drawing.Point(241, 30)
        Me.TextBoxnome.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxnome.Name = "TextBoxnome"
        Me.TextBoxnome.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxnome.TabIndex = 0
        '
        'TextBoxgenero
        '
        Me.TextBoxgenero.Location = New System.Drawing.Point(241, 78)
        Me.TextBoxgenero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxgenero.Name = "TextBoxgenero"
        Me.TextBoxgenero.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxgenero.TabIndex = 1
        '
        'TextBoxsessoes
        '
        Me.TextBoxsessoes.Location = New System.Drawing.Point(241, 230)
        Me.TextBoxsessoes.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxsessoes.Name = "TextBoxsessoes"
        Me.TextBoxsessoes.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxsessoes.TabIndex = 6
        '
        'TextBoxsala
        '
        Me.TextBoxsala.Location = New System.Drawing.Point(241, 180)
        Me.TextBoxsala.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxsala.Name = "TextBoxsala"
        Me.TextBoxsala.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxsala.TabIndex = 7
        '
        'TextBoxidade
        '
        Me.TextBoxidade.Location = New System.Drawing.Point(241, 130)
        Me.TextBoxidade.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxidade.Name = "TextBoxidade"
        Me.TextBoxidade.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxidade.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(156, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 17)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Título"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(156, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 17)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Género"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(131, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(91, 17)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Idade mínima"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(156, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 17)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Sala"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(149, 234)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 17)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Sessões"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(465, 64)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(165, 31)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Novo Filme"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(465, 123)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(165, 30)
        Me.Button2.TabIndex = 15
        Me.Button2.Text = "Remover"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'FormFilmes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBoxidade)
        Me.Controls.Add(Me.TextBoxsala)
        Me.Controls.Add(Me.TextBoxsessoes)
        Me.Controls.Add(Me.TextBoxgenero)
        Me.Controls.Add(Me.TextBoxnome)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "FormFilmes"
        Me.Text = "FormFilmes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxnome As TextBox
    Friend WithEvents TextBoxgenero As TextBox
    Friend WithEvents TextBoxsessoes As TextBox
    Friend WithEvents TextBoxsala As TextBox
    Friend WithEvents TextBoxidade As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
End Class

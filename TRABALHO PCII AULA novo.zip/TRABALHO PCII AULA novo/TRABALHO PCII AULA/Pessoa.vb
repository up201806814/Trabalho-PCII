﻿Public Class Pessoa

    Private _nomecomp As String
    Private _username As String
    Private _password As String
    Private _nivel As Integer

    Public Sub New()

    End Sub

    'Public Sub New(ByVal nomecomp As String, ByVal username As String, ByVal password As String, nivel As Integer)
    Public Sub New(ByVal username As String, ByVal password As String, ByVal nivel As Integer)
        Me.Nomecomp = Nomecomp
        Me.Username = username
        Me.Password = password
        Me.Nivel = nivel


    End Sub

    Public Property Nomecomp As String
        Get
            Return _nomecomp
        End Get
        Set(value As String)
            _nomecomp = value
        End Set
    End Property

    Public Property Username As String
        Get
            Return _username
        End Get
        Set(value As String)
            _username = value
        End Set
    End Property

    Public Property Password As String
        Get
            Return _password
        End Get
        Set(value As String)
            _password = value
        End Set
    End Property

    Public Property Nivel As Integer
        Get
            Return _nivel
        End Get
        Set(value As Integer)
            _nivel = value
        End Set
    End Property

    Public Overridable Function ParaStr() As String

        Dim temp As String

        temp = Me.Nomecomp

        Return temp

    End Function

End Class

﻿Imports TRABALHO_PCII_AULA

Public Class Venda


    Private _listafilmes As Filmes
    Private _filme As Filme
    Private _cliente As Cliente
    Private _qtd As Integer

    Public Property Qtd As Integer
        Get
            Return _qtd
        End Get
        Set(value As Integer)
            _qtd = value
        End Set
    End Property

    Public Property Cliente As Cliente
        Get
            Return _cliente
        End Get
        Set(value As Cliente)
            _cliente = value
        End Set
    End Property

    Public Property Filme As Filme
        Get
            Return _filme
        End Get
        Set(value As Filme)
            _filme = value
        End Set
    End Property

    Public Property Listafilmes As Filmes
        Get
            Return _listafilmes
        End Get
        Set(value As Filmes)
            _listafilmes = value
        End Set
    End Property

    Sub New(f As Filme, c As Cliente, l As Single, q As Integer)
        _filme = f
        _cliente = c
        _qtd = q
    End Sub

    Sub New()

    End Sub

    Public Function receitafilme(ByVal nomefilme As String) As Single
        Me.Filme.Titulo = nomefilme

        Dim receita As Single

        For i = 0 To Listafilmes.Count

            If Listafilmes(i).Titulo = Me.Filme.Titulo Then

                For j = 1 To Listafilmes(i).Numerosessoes

                    Me.Qtd = listasalas(Listafilmes(i).Sala).Nlugares - (Listafilmes(i).Listasessoes(j).Lugardispnormal + Listafilmes(i).Listasessoes(j).Lugardispvip)
                    receita = (listasalas(Listafilmes(i).Sala).Ncolunas * 3 - Listafilmes(i).Listasessoes(j).Lugardispvip) * precovip
                    receita = receita + ((listasalas(Listafilmes(i).Sala).Nlugares - listasalas(Listafilmes(i).Sala).Ncolunas * 3) - Listafilmes(i).Listasessoes(j).Lugardispnormal) * preconormal
                Next


            End If

        Next


        Return receita

    End Function

    Public Function receitatotal() As Integer

        Dim receitat As Single


        For i = 0 To Listafilmes.Count

            receitat = receitat + receitafilme(Listafilmes(i).Titulo)

        Next

        Return receitat


    End Function

End Class

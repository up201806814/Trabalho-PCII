﻿Module Varglobais

    'Ver o que estava em cinema pq cinema=varglobais
    'é preciso pôr aqui todinhas as classes do nosso projeto? 
    'como se trabalhará com gastos e lucro? ou a receita é só através de bilhetes vendidos?
    'é preciso news em tudo?

    Public preconormal As Single = 7
    Public precovip As Single = 10
    Public listaclientes As Clientes
    Public administrador As New Administrador
    Public listafilmes As Filmes
    Public listavendas As Vendas
    Public fadmin As FormAdministrador
    Public fcontas As ContasCinema
    Public listasalas As Salas
    Public vendacinema As Venda



    Public Sub gravarclientes()
        Dim writer As New System.Xml.Serialization.XmlSerializer(GetType(Clientes))

        Dim file As New System.IO.StreamWriter("listaclientes")

        writer.Serialize(file, listaclientes)

        file.Close()
    End Sub

    Public Sub gravarfilmes()
        Dim writer As New System.Xml.Serialization.XmlSerializer(GetType(Filmes))

        Dim file As New System.IO.StreamWriter("listafilmes")

        writer.Serialize(file, listafilmes)

        file.Close()
    End Sub

    Public Sub gravarvendas()
        Dim writer As New System.Xml.Serialization.XmlSerializer(GetType(Vendas))

        Dim file As New System.IO.StreamWriter("listavendas")

        writer.Serialize(file, listavendas)

        file.Close()
    End Sub

    'temos de pôr nos filmes ou noutra classe o preço por bilhete e o lucro que daí advém para o cinema

    'Public Sub calculargastos()
    '    Dim g As Single
    '    For i = 0 To listafilmes.Count - 1
    '        g = g + listafilmes.item(i).Gasto
    '    Next
    '    gastos = g
    'End Sub

    'Public Sub calcularganho()
    '    Dim g As Single
    '    For i = 0 To listafilmes.Count - 1
    '        g = g + listafilmes.item(i).Ganho
    '    Next
    '    ganho = g
    'End Sub




End Module

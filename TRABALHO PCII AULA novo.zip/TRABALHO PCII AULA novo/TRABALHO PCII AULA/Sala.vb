﻿Public Class Sala
    ''acrescentei o nlugares porque apesar de termos o numero de filas  o numero de colunas acho melhor termos uma variavel para guardar essa info
    'Como vamos criar as salas?

    Private _tipo As String
    Private _tipolugares As String
    Private _nfilas As Integer
    Private _ncolunas As Integer
    Private _nlugares As Integer
    Private _ocupado As Boolean = False
    Private _nomefilme As String
    Private _lugares(,) As String


    Public Sub New()

    End Sub

    Public Sub New(ByVal tipo As String, ByVal nfilas As Integer, ByVal ncolunas As Integer, ByVal tipolugares As String)
        Me.Tipo = tipo
        Me.Nlugares = Nlugares
        Me.Tipolugares = tipolugares
        Me.Nfilas = nfilas
        Me.Ncolunas = ncolunas

    End Sub
    Public Property Tipo As String
        Get
            Return _tipo
        End Get
        Set(value As String)
            _tipo = value
        End Set
    End Property

    Public Property Nlugares As Integer
        Get
            Return _nlugares
        End Get
        Set(value As Integer)
            _nlugares = value
        End Set
    End Property

    Public Property Tipolugares As String
        Get
            Return _tipolugares
        End Get
        Set(value As String)
            _tipolugares = value
        End Set
    End Property

    Public Property Nfilas As Integer
        Get
            Return _nfilas
        End Get
        Set(value As Integer)
            _nfilas = value
        End Set
    End Property

    Public Property Ncolunas As Integer
        Get
            Return _ncolunas
        End Get
        Set(value As Integer)
            _ncolunas = value
        End Set
    End Property

    Public Property Nomefilme As String
        Get
            Return _nomefilme
        End Get
        Set(value As String)
            _nomefilme = value
        End Set
    End Property


    Public Property Ocupado As Boolean
        Get
            Return _ocupado
        End Get
        Set(value As Boolean)
            _ocupado = value
        End Set
    End Property

    Public Property Lugares As String(,)
        Get
            Return _lugares
        End Get
        Set(value As String(,))
            _lugares = value
        End Set
    End Property

    Public Sub marcarsala(ByVal nomefilme As String)

        If Ocupado <> True Then

            Ocupado = True
            Me.Nomefilme = nomefilme
        End If


    End Sub

    Public Sub formarsala(ByVal ncolunas As Integer, ByVal nlinhas As Integer)

        Dim i As Integer = 1

        For m = 0 To listasalas.Count - 1

            For i = 1 To nlinhas

                If i < 11 Then

                    For j = 1 To ncolunas

                        Lugares(i, j) = Lugares(Asc(i + 64), j)

                    Next

                End If

                Exit For

            Next
        Next

    End Sub

End Class


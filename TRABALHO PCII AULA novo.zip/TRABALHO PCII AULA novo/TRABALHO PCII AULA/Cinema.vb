﻿Public Class Cinema
    Private _listasessoes As Sessoes
    Private _listaclientes As Clientes
    Private _listafilmes As Filmes
    Private _listasalas As Sala
    Private _a As Administrador


    Public Sub New()
        Me.Listaclientes = New Clientes
        Me.Listafilmes = New Filmes
        Me.Listasalas = New Sala
        Me.A = New Administrador
        Me.Listasessoes = New Sessoes

    End Sub

    Public Property Listasessoes As Sessoes
        Get
            Return _listasessoes
        End Get
        Set(value As Sessoes)
            _listasessoes = value
        End Set
    End Property

    Public Property Listaclientes As Clientes
        Get
            Return _listaclientes
        End Get
        Set(value As Clientes)
            _listaclientes = value
        End Set
    End Property

    Public Property Listafilmes As Filmes
        Get
            Return _listafilmes
        End Get
        Set(value As Filmes)
            _listafilmes = value
        End Set
    End Property

    Public Property Listasalas As Sala
        Get
            Return _listasalas
        End Get
        Set(value As Sala)
            _listasalas = value
        End Set
    End Property

    Public Property A As Administrador
        Get
            Return _a
        End Get
        Set(value As Administrador)
            _a = value
        End Set
    End Property

    Sub gravar()

        Dim writer As New System.Xml.Serialization.XmlSerializer(GetType(Cinema))

        Dim file As New System.IO.StreamWriter("OsMeusDados.xml")

        writer.Serialize(file, Me)

        file.Close()

    End Sub

    Public Function ler() As Cinema
        Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(Cinema))

        Dim file As New System.IO.StreamReader("OsMeusDados.xml")

        Dim MyObject As Cinema
        MyObject = CType(reader.Deserialize(file), Cinema)

        file.Close()

        Return MyObject

    End Function

End Class

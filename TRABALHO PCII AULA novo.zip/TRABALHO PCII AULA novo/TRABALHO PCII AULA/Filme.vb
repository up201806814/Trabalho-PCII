﻿Imports TRABALHO_PCII_AULA

Public Class Filme


    Private _listasessoes As Sessoes
    Private _titulo As String
    Private _genero As String
    Private _idademinima As Integer
    Private _sala As Integer
    Private _numerosessoes As Integer


    Public Sub New()

    End Sub

    Public Sub New(ByVal titulo As String, ByVal genero As String, ByVal idademinima As Integer, ByVal numerosessoes As Integer, ByVal sala As Integer)

        Me.Titulo = titulo
        Me.Genero = genero
        Me.Idademinima = idademinima
        Me.Numerosessoes = numerosessoes
        Me.Sala = sala
    End Sub


    Public Property Listasessoes As Sessoes
        Get
            Return _listasessoes
        End Get
        Set(value As Sessoes)
            _listasessoes = value
        End Set
    End Property

    Public Property Titulo As String
        Get
            Return _titulo
        End Get
        Set(value As String)
            _titulo = value
        End Set
    End Property

    Public Property Genero As String
        Get
            Return _genero
        End Get
        Set(value As String)
            _genero = value
        End Set
    End Property

    Public Property Idademinima As Integer
        Get
            Return _idademinima
        End Get
        Set(value As Integer)
            _idademinima = value
        End Set
    End Property

    Public Property Sala As Integer
        Get
            Return _sala
        End Get
        Set(value As Integer)
            _sala = value
        End Set
    End Property

    Public Property Numerosessoes As Integer
        Get
            Return _numerosessoes
        End Get
        Set(value As Integer)
            _numerosessoes = value
        End Set
    End Property

    Public Function ParaStr() As String
        Dim temp As String

        temp = Me._titulo & vbTab & Me._genero & vbTab & Me._idademinima

        Return temp
    End Function


    Public Sub marcarfilme(ByVal nome As String, ByVal idminima As Integer, ByVal genero As String, ByVal sala As Integer)

        Me.Titulo = nome
        Me.Genero = genero
        Me.Idademinima = idminima


    End Sub

    Public Sub adicionarsessao(ByVal nlinhas As Integer, ByVal ncolunas As Integer, ByVal a As Integer)

        Dim lugares(nlinhas, ncolunas) As String
        Dim sessao As Sessao

        sessao = New Sessao(3 * ncolunas, (nlinhas - 3) * ncolunas, lugares)

        Listasessoes.Add(sessao)

    End Sub


End Class

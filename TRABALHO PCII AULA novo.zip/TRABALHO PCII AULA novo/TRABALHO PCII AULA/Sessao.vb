﻿Imports TRABALHO_PCII_AULA

'Como vamos criar as sessoes? Impomos que há x sessões por dia a y horas e só mudamos de sala para sala senão fica demasiado simples (supostamente)?
'será que há alguma maneira de pondo a sala abrir uma datagridview com linhas e colunas pré-definidas para essa mesma sala? e dps é clicar nos espaços e tcharam?

Public Class Sessao
    Private _lugardispvip As Integer
    Private _lugardispnormal As Integer
    Private _lugar(,) As String



    Public Sub New()

    End Sub

    Public Sub New(ByVal lugardispvip As Integer, ByVal lugardispnormal As Integer, ByVal lug(,) As String)

        Me.Lugardispnormal = lugardispnormal
        Me.Lugardispvip = lugardispvip
        Me.Lugar = lug


    End Sub
    Public Property Lugardispvip As Integer
        Get
            Return _lugardispvip
        End Get
        Set(value As Integer)
            _lugardispvip = value
        End Set
    End Property

    Public Property Lugardispnormal As Integer
        Get
            Return _lugardispnormal
        End Get
        Set(value As Integer)
            _lugardispnormal = value
        End Set
    End Property

    Public Property Lugar As String(,)
        Get
            Return _lugar
        End Get
        Set(value As String(,))
            _lugar = value
        End Set
    End Property




    'Ver se temos nsala em condições
    Sub verificanormal(ByVal nsala As Integer)
        Dim k, j As Integer
        Dim aux As Boolean = False
        Dim lugarfila, lugarcoluna As Integer

        k = 4
        j = 1
        While k <= Listasalas(nsala).Nfilas
            While j <= Listasalas(nsala).Ncolunas
                If Me.Lugar(k, j) = "" Then
                    aux = True
                    lugarfila = k
                    lugarcoluna = j

                    Exit While
                Else
                    aux = False
                End If

                j = j + 1
            End While

            k = k + 1
        End While

        If aux = False Then
            MsgBox("Não há lugares disponíveis")
        End If

    End Sub

    Sub verificavip(ByVal nsala As Integer)
        'Considera-se que as primeiras 3 filas de cada sala são lugares vip
        Dim k, j As Integer
        Dim aux As Boolean = False
        Dim lugarfila, lugarcoluna As Integer

        k = 1
        j = 1
        While k <= 3
            While j <= listasalas(nsala).Ncolunas
                If Me.Lugar(k, j) = "" Then
                    aux = True
                    lugarfila = k
                    lugarcoluna = j
                    Exit While
                Else
                    aux = False

                End If

                j = j + 1
            End While

            k = k + 1
        End While

        If aux = False Then
            MsgBox("Não há lugares disponíveis")
        End If

    End Sub


    Sub atribuilugarnormal(ByVal nsala As Integer, ByVal lugarfila As Integer, ByVal lugarcoluna As Integer)
        Call verificanormal(nsala)
        'Lugar(lugarfila, lugarcoluna) = 'dados da pessoa

    End Sub

    'Existir campo que será para saber se é vip ou não
    Sub atribuilugarvip(ByVal nsala As Integer, ByVal lugarfila As Integer, ByVal lugarcoluna As Integer)
        Call verificanormal(nsala)
        ' Lugar(lugarfila, lugarcoluna) = 'dados da pessoa

    End Sub

End Class

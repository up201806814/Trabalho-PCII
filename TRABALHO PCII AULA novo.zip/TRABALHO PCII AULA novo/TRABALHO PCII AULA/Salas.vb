﻿Public Class Salas
    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewSala As Sala)
        Me.List.Add(NewSala)
    End Sub

    Public Sub Remove(ByVal oldSala As Sala)
        Me.List.Remove(oldSala)
    End Sub

    Default Public Property item(ByVal index As Integer) As Sala
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As Sala)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewSala As Sala)
        Me.List.Insert(index, NewSala)
    End Sub
End Class

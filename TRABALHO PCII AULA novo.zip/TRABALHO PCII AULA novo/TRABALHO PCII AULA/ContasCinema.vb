﻿Public Class ContasCinema

    Private Sub ContasCinema_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        TextBoxreceitatotal.Text = vendacinema.receitatotal

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click

        TextBoxreceitafilme.Text = vendacinema.receitafilme(ComboBox1.Text)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        For i = 0 To listafilmes.Count - 1

            Me.ComboBox1.Items.Add(listafilmes(i).Titulo)

        Next



    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class
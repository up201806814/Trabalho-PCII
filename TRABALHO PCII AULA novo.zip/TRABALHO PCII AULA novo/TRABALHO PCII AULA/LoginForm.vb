Public Class LoginForm

    Public Event LoginOK(ByVal NomeUser As String)
    Public Event LoginErro(ByVal NomeUser As String, ByVal Erro As String)
    Public erro As String

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See https://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Dim loginok As Boolean

        ValidaLogin(Me.UsernameTextBox.Text, Me.PasswordTextBox.TextLength, loginok)
        _loginok = loginok

        If _loginok = True Then
            RaiseEvent loginok(UsernameTextBox.Text)
            Me.Close()
        Else
            RaiseEvent LoginErro("", Me.erro)
        End If

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        _loginok = False
        RaiseEvent LoginErro(Me.UsernameTextBox.Text, "Login Cancelado")
        Me.Close()
    End Sub

    'Faltam os eventos e a programa��o do bot�o ok



    Private Sub ValidaLogin(ByVal NomeUser As String, ByVal Password As String, ByRef loginok As Boolean)
        'Dim aux As Integer = 0


        'For i = 0 To listaclientes.Count - 1
        '    If NomeUser = listaclientes(i).Username Then
        '        If listaclientes(i).Password = Password Then
        '            loginok = True

        '        Else
        '            MsgBox("A password est� incorreta!")
        '        End If
        '        aux = aux + 1
        '    End If
        'Next

        'Login do Administrador, deu erro

        'If NomeUser = Administrador.Username Then
        '    If Administrador.Password = Password Then
        '        loginok = True
        '    Else
        '        MsgBox("A password est� incorreta!")

        '    End If
        Dim erro As String


        If UsernameTextBox.Text = "admin" And PasswordTextBox.Text = "12345" Then
            currentpessoa = New Pessoa("admin", "12345", 1)
            loginok = True
        Else
            For i = 0 To listaclientes.Count - 1
                If UsernameTextBox.Text = listaclientes(i).Username Then
                    If listaclientes(i).Password = Password Then
                        loginok = True

                    Else
                        erro = MsgBox("A password est� incorreta!")
                        loginok = False
                    End If
                Else
                    erro = MsgBox("Esse nome de utilizador n�o se encontra na nossa base de dados!")
                    loginok = False
                End If
            Next

        End If




        'If aux = 0 Then
        '        MsgBox("Esse nome de utilizador n�o se encontra na nossa base de dados!")

        '        reencaminha()

        '    End If
    End Sub








    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UsernameTextBox.Text = ""
        PasswordTextBox.Text = ""
        listaclientes = New Clientes
        listavendas = New Vendas
        fadmin = New FormAdministrador
        listafilmes = New Filmes
        ler()




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        reencaminha()
    End Sub

    'Como fazer para ler o administrador??

    Sub lerclientes()
        Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(Clientes))

        Dim file As New System.IO.StreamReader("listaclientes")

        listaclientes = CType(reader.Deserialize(file), Clientes)

        file.Close()
    End Sub

    Sub lerfilmes()
        Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(Filmes))

        Dim file As New System.IO.StreamReader("listafilmes")

        listafilmes = CType(reader.Deserialize(file), Filmes)

        file.Close()
    End Sub


    Sub lervendas()
        Dim reader As New System.Xml.Serialization.XmlSerializer(GetType(Vendas))

        Dim file As New System.IO.StreamReader("listavendas")

        listavendas = CType(reader.Deserialize(file), Vendas)

        file.Close()
    End Sub
    Sub ler()
        lerclientes()
        lerfilmes()
        lervendas()
    End Sub

    Private Sub UsernameTextBox_TextChanged(sender As Object, e As EventArgs) Handles UsernameTextBox.TextChanged

    End Sub


    Sub reencaminha()

        Dim formconta As CriarConta
        formconta = New CriarConta
        formconta.Show()

    End Sub


End Class

﻿Public Class Filmes

    Inherits Collections.CollectionBase

    Public Sub Add(ByVal NewFilme As Filme)
        Me.List.Add(NewFilme)
    End Sub

    Public Sub Remove(ByVal oldFilme As Filme)
        Me.List.Remove(oldFilme)
    End Sub

    Default Public Property item(ByVal index As Integer) As Filme
        Get
            Return Me.List.Item(index)
        End Get
        Set(ByVal value As Filme)
            Me.List.Item(index) = value
        End Set
    End Property

    Public Shadows Sub clear()
        MyBase.Clear()
    End Sub

    Public Shadows Sub RemoveAt(ByVal index As Integer)
        Remove(item(index))
    End Sub
    Public Sub InsertAt(ByVal index As Integer, ByVal NewFilme As Filme)
        Me.List.Insert(index, NewFilme)
    End Sub

End Class

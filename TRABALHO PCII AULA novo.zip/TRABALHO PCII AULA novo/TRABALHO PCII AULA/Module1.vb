﻿Module Module1
    Public currentpessoa As Pessoa
End Module

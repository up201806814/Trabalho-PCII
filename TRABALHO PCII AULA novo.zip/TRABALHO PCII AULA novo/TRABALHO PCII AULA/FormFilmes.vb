﻿Public Class FormFilmes

    'inserir e remover filmes
    'como será para inserir packs e dps como os escolher??



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'ter em atençao que na textboxsala nao se encontra uma sala mas sim uma string, o mesmo acontece na textboxsessoes, temos de arranjar alternativa a isto


        If Valido() = True Then
            Dim novofilme As New Filme
            'novofilme = New Filme(TextBoxnome.Text, TextBoxgenero.Text, TextBoxidade.Text, TextBoxsessoes.Text, textboxsala.text)


            listafilmes.Add(novofilme)


        End If

    End Sub

    Public Function Valido() As Boolean
        Dim aux As Boolean = True


        If TextBoxgenero.Text <> "" And TextBoxidade.Text <> "" And TextBoxnome.Text <> "" And TextBoxsala.Text = "" And TextBoxsessoes.Text = "" Then
            For i = 0 To listafilmes.Count - 1
                If TextBoxnome.Text = listafilmes(i).Titulo Then

                    MsgBox("O filmes que pretende adicionar ja existe")
                    aux = False

                ElseIf TextBoxsala.Text = Str(listafilmes(i).Sala) Then
                    MsgBox("A sala onde pretende exibir o filme encontra-se ocupada")
                    aux = False
                End If
            Next
        ElseIf listasalas.Count < listafilmes.Count + 1 Then
            MsgBox("Não há salas disponiveis para alocar o filme")
            aux = False

        Else
            MsgBox("Por favor preencha todos os campos indicados")
            aux = False

        End If

        Return aux


    End Function

    Public Function Existe() As Boolean
        Dim aux As Boolean = False

        If TextBoxgenero.Text <> "" And TextBoxidade.Text <> "" And TextBoxnome.Text <> "" And TextBoxsala.Text = "" And TextBoxsessoes.Text = "" Then
            For i = 0 To listafilmes.Count - 1
                If TextBoxnome.Text = listafilmes(i).Titulo And TextBoxgenero.Text = listafilmes(i).Genero And TextBoxidade.Text = listafilmes(i).Idademinima And TextBoxsala.Text = listafilmes(i).Sala And TextBoxsessoes.Text = listafilmes(i).Numerosessoes Then

                    aux = True

                End If
            Next
            If aux = False Then
                MsgBox("O filme que pretende remover não existe")
            End If

        Else
            MsgBox("Por favor preencha todos os campos indicados")
            aux = False

        End If

        Return aux


    End Function


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        If Existe() = True Then
            Dim filmeremover As New Filme

            filmeremover = New Filme(TextBoxnome.Text, TextBoxgenero.Text, TextBoxidade.Text, TextBoxsessoes.Text, TextBoxsala.Text)

            For i = 0 To listafilmes.Count - 1
                If listafilmes(i).Titulo = filmeremover.Titulo Then
                    listafilmes.RemoveAt(i)
                End If
            Next

        End If


    End Sub


















    Private Sub FormFilmes_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
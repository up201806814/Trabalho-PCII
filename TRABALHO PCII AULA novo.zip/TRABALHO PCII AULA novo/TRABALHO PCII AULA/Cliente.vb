﻿Imports TRABALHO_PCII_AULA

Public Class Cliente : Inherits Pessoa

    Private _nif As String
    Private _valortotal As Single
    Private _listafilmesassist As Filmes

    Public Sub New()

    End Sub

    Public Sub New(ByVal nomecomp As String, ByVal password As String, ByVal username As String, ByVal nif As String)

        MyBase.New(nomecomp, username, password)

        Me.Nif = nif
    End Sub
    Public Sub New(ByVal nomecomp As String, ByVal password As String, ByVal username As String, ByVal nif As String, ByVal valortotal As Single, ByVal listafilmesassist As Filmes)

        MyBase.New(nomecomp, username, password)
        Me.Valortotal = valortotal
        Me.Nif = nif
        Me.Listafilmesassist = listafilmesassist

    End Sub
    Public Property Nif As String
        Get
            Return _nif
        End Get
        Set(value As String)
            _nif = value
        End Set
    End Property

    Public Property Valortotal As Single
        Get
            Return _valortotal
        End Get
        Set(value As Single)
            _valortotal = value
        End Set
    End Property

    Public Property Listafilmesassist As Filmes
        Get
            Return _listafilmesassist
        End Get
        Set(value As Filmes)
            _listafilmesassist = value
        End Set
    End Property

    Public Overrides Function ParaStr() As String
        Return MyBase.ParaStr()
    End Function

End Class

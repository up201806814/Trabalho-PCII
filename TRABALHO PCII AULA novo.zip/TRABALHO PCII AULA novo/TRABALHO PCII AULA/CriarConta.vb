﻿Public Class CriarConta

    'Como se fará para o administrador??
    'admin: nivel 1 
    'user: nivel 0 


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim c As Cliente
        If Nomeutilizador(username.Text) = True And passwordvalida(password.Text) = True Then
            c = New Cliente(username.Text, password.Text, nomecompleto.Text, nif.Text)
            listaclientes.Add(c)
            gravar()
            MsgBox("Bem vindo " & nomecompleto.Text & "!")
            Me.Close()
        ElseIf Nomeutilizador(username.Text) = False And passwordvalida(password.Text) = True Then
            MsgBox("O username já se encontra em uso!")
        ElseIf Nomeutilizador(username.Text) = True And passwordvalida(password.Text) = False Then
            MsgBox("A password é demasiado curta, deve ter 8 ou mais caracteres!")
        ElseIf Nomeutilizador(username.Text) = False And passwordvalida(password.Text) = False Then
            MsgBox("O username já se encontra em uso e a password é demasiado curta, deve ter 8 ou mais caracteres!")
        End If
        gravarclientes()
    End Sub

    Function Nomeutilizador(u As String)
        Dim valido As Boolean = True
        If listaclientes.Count > 0 Then
            For i = 0 To listaclientes.Count - 1
                If u = listaclientes(i).Username Then
                    valido = False
                End If
            Next
        ElseIf listaclientes.Count = 0 Then
            valido = True
        End If
        Return valido
    End Function

    Function passwordvalida(p As String)
        Dim valida As Boolean = False
        If Len(p) >= 8 Then
            valida = True
        End If
        Return valida
    End Function

    Sub gravar()
        Dim writer As New System.Xml.Serialization.XmlSerializer(GetType(Clientes))

        Dim file As New System.IO.StreamWriter("ficheiro")

        writer.Serialize(file, listaclientes)

        file.Close()
    End Sub

    Private Sub CriarConta_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub username_TextChanged(sender As Object, e As EventArgs) Handles username.TextChanged

    End Sub
End Class
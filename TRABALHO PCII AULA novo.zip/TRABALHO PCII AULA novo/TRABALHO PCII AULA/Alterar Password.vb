﻿Public Class Alterar_Password

    'Falta verificar para o administrador



    Private Sub Alterar_Password_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub alterar_Click(sender As Object, e As EventArgs) Handles alterar.Click


        If passantiga.Text <> listaclientes(ncliente).Password Then
            MsgBox("A password que introduziu não é igual à atual")
        ElseIf passantiga.Text = listaclientes(ncliente).Password Then
            If passnova.Text = passrepetida.Text Then
                If passwordvalida(passnova.Text) = True Then
                    listaclientes(ncliente).Password = passnova.Text
                    MsgBox("Mudança concluida com sucesso.")
                    Me.Close()
                    gravarclientes()
                Else
                    MsgBox("A nova password deve ter 8 ou mais caracteres para ser válida!")
                End If
            Else
                MsgBox("As passwords não coincidem!")
            End If
        End If

    End Sub
    Function passwordvalida(p As String)
        Dim valida As Boolean = False
        If Len(p) >= 8 Then
            valida = True
        End If
        Return valida
    End Function

    Private Sub passantiga_TextChanged(sender As Object, e As EventArgs) Handles passantiga.TextChanged

    End Sub

    Private Sub passrepetida_TextChanged(sender As Object, e As EventArgs) Handles passrepetida.TextChanged

    End Sub
End Class
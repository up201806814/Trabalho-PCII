﻿Public Class Administrador : Inherits Pessoa

    Public Sub New()

    End Sub

    Public Sub New(ByVal nomecomp As String, ByVal username As String, ByVal password As String)
        MyBase.New(nomecomp, username, password)

    End Sub
End Class

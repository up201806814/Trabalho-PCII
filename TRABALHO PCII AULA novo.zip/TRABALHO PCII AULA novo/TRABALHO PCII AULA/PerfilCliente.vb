﻿Public Class PerfilCliente
    'Está em branco. 
    'Equivalente ao dados cliente. 
    'sempre será só o administrador a comprar ou o cliente poderá? ou a única coisa do seu perfil será consulta de histórico e aos bilhetes?
    'O administrador escolhe o filme através daquela barra que tinhamos falado à prof?
    'pelo data grid view supostamente ao clicar no quadrado posso preencher não é? querem pôr a selecionar lugares assim? Os vazios a verde e os ocupados a vermelho? É o mais intuitivo e mais real..
    'escolher filme-ver se há promoçao (será que é preciso uma classe promocao e dps collection promocoes?) -pôr a quantidade de bilhetes-escolher a sessao-escolher lugares-imprimir bilhete e gravar e somar receita
    'como aparecerá o bilhete??



    Private Sub PerfilCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' alterarpass.Show()
    End Sub

    Private Sub DataGridView1_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        Dim k, j As Integer
        Dim temp As String
        k = 0
        While k <= listaclientes.Count - 2
            j = k + 1

            While j <= listaclientes.Count - 1
                If listaclientes(k).Nomecomp > listaclientes(j).Nomecomp Then
                    temp = listaclientes(k).Nomecomp
                    listaclientes(k).Nomecomp = listaclientes(j).Nomecomp
                    listaclientes(j).Nomecomp = temp
                End If

                j = j + 1
            End While
            k = k + 1
        End While


        For i = 0 To listaclientes.Count - 1
            Me.ComboBox1.Items.Add(listaclientes(i).Nomecomp)

        Next

    End Sub
End Class